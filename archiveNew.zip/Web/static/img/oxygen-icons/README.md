# Oxygen Icons

Oxygen icon theme

## Introduction

Oxygen-icons is a freedesktop.org compatible icon theme.
