<?php declare(strict_types=1);
namespace openvk\Web\Presenters;
use openvk\Web\Models\Entities\IP;
use openvk\Web\Models\Entities\User;
use openvk\Web\Models\Entities\PasswordReset;
use openvk\Web\Models\Repositories\IPs;
use openvk\Web\Models\Repositories\Users;
use openvk\Web\Models\Repositories\Restores;
use openvk\Web\Util\Validator;
use Chandler\Session\Session;
use Chandler\Security\User as ChandlerUser;
use Chandler\Security\Authenticator;
use Chandler\Database\DatabaseConnection;
use lfkeitel\phptotp\{Base32, Totp};

final class AuthPresenter extends OpenVKPresenter
{
    protected $banTolerant = true;
    
    private $authenticator;
    private $db;
    private $users;
    private $restores;
    
    function __construct(Users $users, Restores $restores)
    {
        $this->authenticator = Authenticator::i();
        $this->db = DatabaseConnection::i()->getContext();
        
        $this->users    = $users;
        $this->restores = $restores;
        
        parent::__construct();
    }
    
    private function ipValid(): bool
    {
        $ip  = (new IPs)->get(CONNECTING_IP);
        $res = $ip->rateLimit(0);
        
        return $res === IP::RL_RESET || $res === IP::RL_CANEXEC;
    }
    
    function renderRegister(): void
    {
        if(!is_null($this->user))
            $this->redirect("/id" . $this->user->id, static::REDIRECT_TEMPORARY);
        
        if(!$this->hasPermission("user", "register", -1)) exit("Вас забанили");
        
        $referer = NULL;
        if(!is_null($refLink = $this->queryParam("ref"))) {
            $pieces = explode(" ", $refLink, 2);
            if(sizeof($pieces) !== 2)
                $this->flashFail("err", tr("error"), tr("referral_link_invalid"));
            
            [$ref, $hash] = $pieces;
            $ref  = hexdec($ref);
            $hash = base64_decode($hash);
            
            $referer = (new Users)->get($ref);
            if(!$referer)
                $this->flashFail("err", tr("error"), tr("referral_link_invalid"));
            
            if($referer->getRefLinkId() !== $refLink)
                $this->flashFail("err", tr("error"), tr("referral_link_invalid"));
        }
        
        $this->template->referer = $referer;
        
        if($_SERVER["REQUEST_METHOD"] === "POST") {
            $this->assertCaptchaCheckPassed();

            if(!OPENVK_ROOT_CONF['openvk']['preferences']['registration']['enable'] && !$referer)
                $this->flashFail("err", tr("failed_to_register"), tr("registration_disabled"));
            
            if(!$this->ipValid())
                $this->flashFail("err", tr("suspicious_registration_attempt"), tr("suspicious_registration_attempt_comment"));
            
            if(!Validator::i()->emailValid($this->postParam("email")))
                $this->flashFail("err", tr("invalid_email_address"), tr("invalid_email_address_comment"));
            
            if (strtotime($this->postParam("birthday")) > time())
                $this->flashFail("err", tr("invalid_birth_date"), tr("invalid_birth_date_comment"));    

            $chUser = ChandlerUser::create($this->postParam("email"), $this->postParam("password"));
            if(!$chUser)
                $this->flashFail("err", tr("failed_to_register"), tr("user_already_exists"));
            
            $user = new User;
            $user->setUser($chUser->getId());
            $user->setFirst_Name($this->postParam("first_name"));
            $user->setLast_Name($this->postParam("last_name"));
            $user->setSex((int) ($this->postParam("sex") === "female"));
            $user->setEmail($this->postParam("email"));
            $user->setSince(date("Y-m-d H:i:s"));
            $user->setRegistering_Ip(CONNECTING_IP);
            $user->setBirthday(strtotime($this->postParam("birthday")));
            $user->save();
            
            if(!is_null($referer)) {
                $user->toggleSubscription($referer);
                $referer->toggleSubscription($user);
            }
            
            $this->authenticator->authenticate($chUser->getId());
            $this->redirect("/id" . $user->getId(), static::REDIRECT_TEMPORARY);
        }
    }
    
    function renderLogin(): void
    {
        $redirUrl = $this->requestParam("jReturnTo");
        
        if(!is_null($this->user))
            $this->redirect($redirUrl ?? "/id" . $this->user->id, static::REDIRECT_TEMPORARY);
        
        if(!$this->hasPermission("user", "login", -1)) exit("Вас забанили");
        
        if($_SERVER["REQUEST_METHOD"] === "POST") {
            
            $user = $this->db->table("ChandlerUsers")->where("login", $this->postParam("login"))->fetch();
            if(!$user)
                $this->flashFail("err", tr("login_failed"), tr("invalid_username_or_password"));
            
            if(!$this->authenticator->verifyCredentials($user->id, $this->postParam("password")))
                $this->flashFail("err", tr("login_failed"), tr("invalid_username_or_password"));

            $secret = $user->related("profiles.user")->fetch()["2fa_secret"];
            $code   = $this->postParam("code");
            if(!is_null($secret)) {
                $this->template->_template = "Auth/LoginSecondFactor.xml";
                $this->template->login     = $this->postParam("login");
                $this->template->password  = $this->postParam("password");

                if(is_null($code))
                    return;

                $ovkUser = new User($user->related("profiles.user")->fetch());
                if(!($code === (new Totp)->GenerateToken(Base32::decode($secret)) || $ovkUser->use2faBackupCode((int) $code))) {
                    $this->flash("err", tr("login_failed"), tr("incorrect_2fa_code"));
                    return;
                }
            }
            
            $this->authenticator->authenticate($user->id);
            $this->redirect($redirUrl ?? "/id" . $user->related("profiles.user")->fetch()->id, static::REDIRECT_TEMPORARY);
            exit;
        }
    }
    
    function renderSu(string $uuid): void
    {
        $this->assertNoCSRF();
        $this->assertUserLoggedIn();
        
        if($uuid === "unset") {
            Session::i()->set("_su", NULL);
            $this->redirect("/", static::REDIRECT_TEMPORARY);
        }
        
        if(!$this->db->table("ChandlerUsers")->where("id", $uuid))
            $this->flashFail("err", tr("token_manipulation_error"), tr("profile_not_found"));
        
        $this->assertPermission('openvk\Web\Models\Entities\User', 'substitute', 0);
        Session::i()->set("_su", $uuid);
        $this->flash("succ", tr("profile_changed"), tr("profile_changed_comment"));
        $this->redirect("/", static::REDIRECT_TEMPORARY);
        exit;
    }
    
    function renderLogout(): void
    {
        $this->assertUserLoggedIn();
        $this->assertNoCSRF();
        $this->authenticator->logout();
        Session::i()->set("_su", NULL);
        
        $this->redirect("/", static::REDIRECT_TEMPORARY_PRESISTENT);
    }
    
    function renderFinishRestoringPassword(): void
    {
        $request = $this->restores->getByToken(str_replace(" ", "+", $this->queryParam("key")));
        if(!$request || !$request->isStillValid()) {
            $this->flash("err", tr("token_manipulation_error"), tr("token_manipulation_error_comment"));
            $this->redirect("/");
            return;
        }

        $this->template->is2faEnabled = $request->getUser()->is2faEnabled();
        
        if($_SERVER["REQUEST_METHOD"] === "POST") {
            if($request->getUser()->is2faEnabled()) {
                $user = $request->getUser();
                $code = $this->postParam("code");
                $secret = $user->get2faSecret();
                if(!($code === (new Totp)->GenerateToken(Base32::decode($secret)) || $user->use2faBackupCode((int) $code))) {
                    $this->flash("err", tr("error"), tr("incorrect_2fa_code"));
                    return;
                }
            }

            $user = $request->getUser()->getChandlerUser();
            $this->db->table("ChandlerTokens")->where("user", $user->getId())->delete(); #Logout from everywhere
            
            $user->updatePassword($this->postParam("password"));
            $this->authenticator->authenticate($user->getId());
            
            $request->delete(false);
            $this->flash("succ", tr("information_-1"), tr("password_successfully_reset"));
            $this->redirect("/settings");
        }
    }
    
    function renderRestore(): void
    {
        if(($this->queryParam("act") ?? "default") === "finish")
            $this->pass("openvk!Auth->finishRestoringPassword");
        
        if($_SERVER["REQUEST_METHOD"] === "POST") {
            $uRow = $this->db->table("ChandlerUsers")->where("login", $this->postParam("login"))->fetch();
            if(!$uRow) {
                #Privacy of users must be protected. We will not tell if email is bound to a user or not.
                $this->flashFail("succ", tr("information_-1"), tr("password_reset_email_sent"));
            }
            
            $user = $this->users->getByChandlerUser(new ChandlerUser($uRow));
            if(!$user)
                $this->flashFail("err", tr("error"), tr("password_reset_error"));
            
            $request = $this->restores->getLatestByUser($user);
            if(!is_null($request) && $request->isNew())
                $this->flashFail("err", tr("forbidden"), tr("password_reset_rate_limit_error"));
            
            $resetObj = new PasswordReset;
            $resetObj->setProfile($user->getId());
            $resetObj->save();
            
            $params = [
                "key"   => $resetObj->getKey(),
                "name"  => $user->getCanonicalName(),
            ];
            $this->sendmail($uRow->login, "password-reset", $params); #Vulnerability possible
            
            
            $this->flashFail("succ", tr("information_-1"), tr("password_reset_email_sent"));
        }
    }
} 
