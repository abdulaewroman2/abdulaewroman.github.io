ALTER TABLE `profiles` ADD COLUMN `website` VARCHAR(128) AFTER `telegram`;
ALTER TABLE `groups` ADD COLUMN `website` VARCHAR(128);
